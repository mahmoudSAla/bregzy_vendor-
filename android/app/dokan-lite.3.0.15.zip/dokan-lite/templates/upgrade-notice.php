<div id="dokan-upgrade-notice"></div>
